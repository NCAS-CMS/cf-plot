=====
cfplot
=====

cfplot is a set of Python plotting routines for contour/vector plots that climate
researchers commonly make.  


Documentation
=============
Please refer to the cfplot homepage http://climate.ncas.ac.uk/~andy/cfplot_sphinx/_build/html


