=======
cf-plot
=======

cf-plot is a set of Python plotting routines for the contour, vector and line plots that climate
researchers commonly make.  


Documentation
=============
Please refer to the cf-plot homepage http://ajheaps.github.io/cf-plot


